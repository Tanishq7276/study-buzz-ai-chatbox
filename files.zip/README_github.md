# 🎓 Study Buddy AI — AI Student Assistant Chatbot

**Code Sangram Online Hackathon 2026 | AI Domain**

> An intelligent AI-powered Student Assistant that provides instant academic support 24/7

**Developer:** Tanishq Gupta
**Institute:** S.B. Jain Institute of Technology, Management & Research, Nagpur

---

## 🚀 Live Demo

👉 **[Click here to try it live](https://YOUR-USERNAME.github.io/study-buddy-ai)**

*(Replace YOUR-USERNAME with your GitHub username after deploying)*

---

## ✨ Features

- ⚡ **Instant Answers** — Real-time AI responses in under 3 seconds
- 🧠 **NLP Powered** — Understands natural language academic queries
- 📚 **7 Subjects** — Maths, Physics, Chemistry, CS, Biology, English, General
- 🌙 **24/7 Available** — Always online for learning support
- 💬 **Conversation Memory** — Remembers context throughout your session
- 🎨 **Stunning UI** — Animated Gen Z design with dark theme

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5, CSS3, Vanilla JavaScript |
| AI Engine | Advanced Language Model API |
| NLP | Natural Language Understanding |
| Fonts | Space Grotesk, DM Mono |
| Deployment | GitHub Pages |

---

## 📋 System Architecture

```
Student (User)
     ↓
Web Interface (HTML/CSS/JS)
     ↓
NLP Input Processing
     ↓
AI Engine (Language Model)
     ↓
Response Generation
     ↓
Student gets instant answer ✅
```

---

## 🏃 How to Run

### Option 1 — GitHub Pages (Recommended)
1. Fork this repository
2. Go to **Settings → Pages**
3. Set source to `main` branch, folder `/root`
4. Your app is live at `https://YOUR-USERNAME.github.io/study-buddy-ai`

### Option 2 — Run Locally
1. Download/clone this repository
2. Open `index.html` in any modern browser
3. Enter your API key and start chatting!

---

## 📸 Subjects Supported

| Subject | Topics Covered |
|---------|---------------|
| 🔢 Mathematics | Algebra, Calculus, Statistics, Geometry |
| ⚡ Physics | Mechanics, Electromagnetism, Quantum Physics |
| 🧪 Chemistry | Organic, Inorganic, Physical Chemistry |
| 💻 Computer Science | DSA, OOP, Algorithms, Big O Notation |
| 🌱 Biology | Genetics, Cell Biology, Photosynthesis |
| 📝 English | Essay Writing, Grammar, Literature |

---

## 🔮 Future Scope

- [ ] Voice-based interaction (Speech-to-Text)
- [ ] Multi-language support (Hindi, Marathi)
- [ ] Integration with Google Classroom
- [ ] Personalized learning recommendations
- [ ] PDF/document upload for context-aware help
- [ ] Progress tracking & analytics dashboard

---

## 🏆 Problem Statement

Students frequently face:
1. **Resource Discovery** — Hard to find study materials quickly
2. **Instant Guidance** — No immediate academic help available
3. **Concept Clarity** — Confusion with difficult topics
4. **Teacher Availability** — Limited access outside class hours

**Study Buddy AI solves all 4 problems with one intelligent solution.**

---

## 📁 Project Structure

```
study-buddy-ai/
│
├── index.html          ← Main application (single file app)
├── README.md           ← Project documentation
└── LICENSE             ← MIT License
```

---

## 👨‍💻 Developer

**Tanishq Gupta**
S.B. Jain Institute of Technology, Management & Research, Nagpur

---

## 📄 License

MIT License — free to use, modify, and distribute.

---

*"Empowering every student with intelligent academic support, available 24/7."*

⭐ **Star this repo if you found it helpful!**
